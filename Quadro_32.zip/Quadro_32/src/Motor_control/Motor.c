/*
 * Motor.c
 *
 * Created: 24.02.2016 19:44:05
 *  Author: J
 */ 

#include <asf.h>
#include <math.h>
#include <arm_math.h>
#include "FreeRTOS.h"
#include "main.h"
#include "Motor.h"

extern volatile	xQueueHandle		Queue_Motor_Task;
volatile short temp=0;

/* D filtrace */
Filter_D(short * D_p,short* D_r,short * D_y)
{	
	#define ARRAY	10
	
	static int32_t Sum_p=0, Sum_r=0, Sum_y=0;
	static short Pole_p[ARRAY], Pole_r[ARRAY], Pole_y[ARRAY];
	static short counter=0;
	
	Sum_p+=D_p;
	Pole_p[counter]=D_p;
	
	Sum_r+=D_r;
	Pole_r[counter]=D_r;
	
	Sum_y+=D_y;
	Pole_y[counter]=D_y;
	
	counter++;
	if (counter==ARRAY) counter=0;
	
	Sum_p-=Pole_p[counter];
	Sum_r-=Pole_r[counter];
	Sum_y-=Pole_y[counter];
	
	*D_p=(short)(Sum_p/ARRAY);
	*D_r=(short)(Sum_r/ARRAY);
	*D_y=(short)(Sum_y/ARRAY);
}

/* PID */
PID_Calculate(Motor_Queue *position,PID_terms *pid)
{	
	volatile short p_p, p_r, p_y;
	static short integral_p, integral_r, integral_y;
	short derivative_p, derivative_r, derivative_y;
	static short prev_error_p, prev_error_r, prev_error_y;
	static const float  dt=0.001f;
	
	/* P slo�ka */
	p_p = 0 - position->pitch;
	p_r = 0 - position->roll;
	p_y = 0 - position->yaw;
	
	/* I polo�ka */
	integral_p = integral_p + p_p*dt;
	integral_r = integral_r + p_r*dt;
	integral_y = integral_y + p_y*dt;
	
	/* D slo�ka */
	derivative_p = (short)((p_p - prev_error_p)/dt);
	derivative_r = (short)((p_r - prev_error_r)/dt);
	derivative_y = (short)((p_y - prev_error_y)/dt);
	
	prev_error_p=p_p;
	prev_error_r=p_r;
	prev_error_y=p_y;
	
	/* filtrace D slo�ky pid - LP */
	//Filter_D(&derivative_p,&derivative_r,&derivative_y);
	
	pid->P_p=p_p;
	pid->P_r=p_r;
	pid->P_y=p_y;
	
	pid->I_p=integral_p;
	pid->I_r=integral_r;
	pid->I_y=integral_y;
	
	pid->D_p=derivative_p;
	pid->D_r=derivative_r;
	pid->D_y=derivative_y;
	
}

/* PWM init function */
void PWM_init(void)
{	
	pwm_channel_t pwm_channel_0;
	pwm_channel_t pwm_channel_1;
	pwm_channel_t pwm_channel_2;
	pwm_channel_t pwm_channel_3;
	
	pmc_enable_periph_clk(ID_PWM);
	pmc_enable_periph_clk(ID_PIOA);
	pmc_enable_periph_clk(ID_PIOB);
	pmc_enable_periph_clk(ID_PIOC);
	
	/* pins */
	pio_configure_pin(PWM_M1,PIO_TYPE_PIO_PERIPH_B);
	//ioport_set_pin_dir(PWM_M1,IOPORT_DIR_OUTPUT);
	
	pio_configure_pin(PWM_M2,PIO_TYPE_PIO_PERIPH_A);
	//ioport_set_pin_dir(PWM_M2,IOPORT_DIR_OUTPUT);
	
	pio_configure_pin(PWM_M3,PIO_TYPE_PIO_PERIPH_B);
//	ioport_set_pin_dir(PWM_M3,IOPORT_DIR_OUTPUT);
	
	pio_configure_pin(PWM_M4,PIO_TYPE_PIO_PERIPH_B);
	//ioport_set_pin_dir(PWM_M4,IOPORT_DIR_OUTPUT);
	 
	/* Disable PWM channels*/
	pwm_channel_disable(PWM, 0);
	pwm_channel_disable(PWM, 1);
	pwm_channel_disable(PWM, 2);
	pwm_channel_disable(PWM, 3);
	
	
	pwm_clock_t clock_setting = {
		.ul_clka = PWM_FREQUENCY * PERIOD_VALUE,
		.ul_clkb = 0,
		.ul_mck = sysclk_get_peripheral_bus_hz(PWM)
	};
	pwm_init(PWM, &clock_setting);
	
	/* Period is left-aligned */
	pwm_channel_0.alignment = PWM_ALIGN_LEFT;
	/* Output waveform starts at a low level */
	pwm_channel_0.polarity =PWM_HIGH;
	/* Use PWM clock A as source clock */
	pwm_channel_0.ul_prescaler = PWM_CMR_CPRE_CLKA;
	/* Period value of output waveform */
	pwm_channel_0.ul_period = PERIOD_VALUE;
	/* Duty cycle value of output waveform */
	pwm_channel_0.ul_duty = 50;
	pwm_channel_0.channel = 0;
	pwm_channel_init(PWM, &pwm_channel_0);
	
	/* Period is left-aligned */
	pwm_channel_1.alignment = PWM_ALIGN_LEFT;
	/* Output waveform starts at a low level */
	pwm_channel_1.polarity = PWM_HIGH;
	/* Use PWM clock A as source clock */
	pwm_channel_1.ul_prescaler = PWM_CMR_CPRE_CLKA;
	/* Period value of output waveform */
	pwm_channel_1.ul_period = PERIOD_VALUE;
	/* Duty cycle value of output waveform */
	pwm_channel_1.ul_duty = 25;
	pwm_channel_1.channel = 1;
	pwm_channel_init(PWM, &pwm_channel_1);
	
	/* Period is left-aligned */
	pwm_channel_2.alignment = PWM_ALIGN_LEFT;
	/* Output waveform starts at a low level */
	pwm_channel_2.polarity = PWM_HIGH;
	/* Use PWM clock A as source clock */
	pwm_channel_2.ul_prescaler = PWM_CMR_CPRE_CLKA;
	/* Period value of output waveform */
	pwm_channel_2.ul_period = PERIOD_VALUE;
	/* Duty cycle value of output waveform */
	pwm_channel_2.ul_duty = 50;
	pwm_channel_2.channel = 2;
	pwm_channel_init(PWM, &pwm_channel_2);
	
	/* Period is left-aligned */
	pwm_channel_3.alignment = PWM_ALIGN_LEFT;
	/* Output waveform starts at a low level */
	pwm_channel_3.polarity = PWM_HIGH;
	/* Use PWM clock A as source clock */
	pwm_channel_3.ul_prescaler = PWM_CMR_CPRE_CLKA;
	/* Period value of output waveform */
	pwm_channel_3.ul_period = PERIOD_VALUE;
	/* Duty cycle value of output waveform */
	pwm_channel_3.ul_duty = 75;
	pwm_channel_3.channel = 3;
	pwm_channel_init(PWM, &pwm_channel_3);

	/*dissable int */
	pwm_channel_disable_interrupt(PWM, 0, 0);
	pwm_channel_disable_interrupt(PWM, 1, 0);
	pwm_channel_disable_interrupt(PWM, 2, 0);
	pwm_channel_disable_interrupt(PWM, 3, 0);
		
	/* Enable PWM channels */
	pwm_channel_enable(PWM, 0);
	pwm_channel_enable(PWM, 1);
	pwm_channel_enable(PWM, 2);
	pwm_channel_enable(PWM, 3);
	
}
 
 
 void Motor_Task(void *pvParameters)
 {
	Motor_Queue Position;
	PID_terms	Pid;
	
	/* PWM inicializace */ 
	PWM_init();
	
	while(1)
	{
		if(xQueueReceive(Queue_Motor_Task,&Position,portMAX_DELAY)==pdPASS)
		{
			//PID_Calculate(&Position,&Pid);
			temp=Pid.P_r;
			if (temp>0)
			{
				delay_ms(1);
			}
			
		}
			 	
	}
 }