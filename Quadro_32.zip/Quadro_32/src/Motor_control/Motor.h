/*
 * Motor.h
 *
 * Created: 24.02.2016 19:45:09
 *  Author: J
 */ 


#ifndef MOTOR_H_
#define MOTOR_H_

//#include "main.h"

/* struct PID */
typedef struct{
	short P_p;
	short I_p;
	short D_p;
	
	short P_r;
	short I_r;
	short D_r;
	
	short P_y;
	short I_y;
	short D_y;
	
}PID_terms;

void Motor_Task(void *pvParameters);
void PWM_init(void);
void PID_Calculate(Motor_Queue *position,PID_terms *pid);
void Filter_D(short * D_p,short* D_r,short * D_y);

#define PWM_FREQUENCY      1000
/** Period value of PWM output waveform */
#define PERIOD_VALUE       500
/** Initial duty cycle value */
#define INIT_DUTY_VALUE    0


#endif /* MOTOR_H_ */